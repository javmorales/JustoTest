//
//  Networking.swift
//  JustoTest
//
//  Created by Javier Morales on 25/01/22.
//

import Foundation

public enum Result<Value> {
    case success(Value)
    case failure(Error)
}

class Networking {
    
    static let shared =  Networking()
    
    static func loadData<T: Decodable>(of type: T.Type = T.self, completion: @escaping (Result<T>) -> Void) {
        guard let url = URL(string: "https://randomuser.me/api/") else {
            print("Invalid URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
            
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let data = data {
                if let decodedResponse = try? JSONDecoder().decode(type, from: data) {
                    DispatchQueue.main.async {
                        completion(.success(decodedResponse))
                    }
                }
            } else {
                print("Fetch failed: \(error?.localizedDescription ?? "Unknown error")")
                completion(.failure(error!))
            }
        }.resume()
    }
    
}
