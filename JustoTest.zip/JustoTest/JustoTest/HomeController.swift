//
//  ViewController.swift
//  JustoTest
//
//  Created by Javier Morales on 25/01/22.
//

import UIKit
import Kingfisher

class HomeController: UIViewController {
    
    
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var avatarImage: UIImageView!
    
    @IBOutlet weak var addressLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        getInformationProfileAndValidateUser()
    
    }
    
}

private extension HomeController {
    
    private func setupView() {
        view.backgroundColor = .lightGray 
    }
    
    private func getInformationProfileAndValidateUser() {
        Networking.loadData(of: Profile.self) { [self] result in
            switch result {
            case .success(let profile):
                let profileData = profile.results[0]
                userNameLabel.text = "\(profileData.name.title ?? "") \(profileData.name.first ?? "") \(profileData.name.last ?? "")"
                emailLabel.text = profileData.email
                let url = URL(string: profileData.picture.large ?? "")
                avatarImage.kf.setImage(with: url!)
                addressLabel.text = "\(profileData.location.street.name ?? "") \(profileData.location.street.number ?? 0)"
                
            case .failure(let error):
                print(error)
                self.showAlert(title: "Error", message: "Error in your account")
            }
        }
    }
    
}

