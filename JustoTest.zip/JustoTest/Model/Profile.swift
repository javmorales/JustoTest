//
//  Profile.swift
//  JustoTest
//
//  Created by Javier Morales on 25/01/22.
//

import Foundation


struct Profile: Decodable {
    let results: [ProfileInformation]
    let info: Info
}

struct ProfileInformation: Decodable {
    let gender: String?
    let name: NameProfile
    let location: LocationProfile
    let email: String?
    let login: LoginProfile
    let dob: DobProfile
    let registered: RegisteredProfile
    let phone: String?
    let cell: String?
    let id: IdProfile
    let picture: PictureProfile
    let nat: String?

}

struct LocationProfile: Decodable {
    let street: StreetProfile
    let city: String?
    let state: String?
    let country: String?
    let postcode: Int?
    let coordinates: CoordinatesProfile
    let timezone: TimeZoneProfile
}

struct PictureProfile: Decodable {
    let large: String?
    let medium: String?
    let thumbnail: String?
}

struct IdProfile: Decodable {
    let name: String?
    let value: String?
}

struct RegisteredProfile: Decodable {
    let date: String?
    let age: Int?
}

struct DobProfile: Decodable {
    let date: String?
    let age: Int?
}

struct LoginProfile: Decodable {
    let uuid: String?
    let username: String?
    let password: String?
    let salt: String?
    let md5: String?
    let sha1: String?
    let sha256: String?
}

struct TimeZoneProfile: Decodable {
    let offset: String?
    let description: String?
}

struct CoordinatesProfile: Decodable {
    let latitude: String?
    let longitude: String?
}

struct StreetProfile: Decodable {
    let number: Int?
    let name: String?
}

struct NameProfile: Decodable {
    let title: String?
    let first: String?
    let last: String?
}

struct Info: Decodable {
    let seed: String?
    let results: Int?
    let page: Int?
    let version: String?
}
